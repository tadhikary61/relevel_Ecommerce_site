const Product = require("../model/product");

exports.getProducts = (req, res) => {
  const products = Product.fetchAll()
    .then((products) => {
      res.render("products", {
        products: products,
      });
    })
    .catch((err) => console.log(err));
};

exports.getProduct = (req, res) => {
  Product.findById(req.params.id).then((product) => {
    console.log(product[0][0]);
    res.render("product", {
      product: product[0][0],
    });
  });
};

exports.getAddProduct = (req, res) => {
  res.render("add-product", {
    isAddProduct: true,
    isEditProduct: false,
  });
};

exports.postAddProduct = (req, res) => {
  console.log(req.body);
  const product = new Product(req.body.name, req.body.price, req.body.category);
  product.save().then((result) => {
    res.redirect("/products");
  });
};

exports.getEditProduct = (req, res) => {
  Product.findById(req.params.id).then((product) => {
    res.render("add-product", {
      isAddProduct: false,
      isEditProduct: true,
      product: product[0][0],
    });
  });
};

exports.postEditProduct = (req, res) => {
  Product.findById(req.params.id)
    .then((product) => {
      return product[0][0];
    })
    .then((product) => {
      return Product.edit(req.params.id, product);
    })
    .then((result) => {
      res.redirect("/products");
    });
};
