const db = require("../util/database");

module.exports = class Product {
  constructor(name, price, category) {
    this.name = name;
    this.price = price;
    this.category = category;
  }

  save() {
    console.log(this.category);
    return db.execute(
      "INSERT INTO products (name, category, price) values (?, ?, ?)",
      [this.name, this.category, +this.price]
    );
  }

  static edit(id, product) {
    console.log(product);
    return db.execute(
      `UPDATE products SET name = 'test', category = ${product.category}, price = ${product.price} WHERE id = ${product.id}`
    );
  }

  static fetchAll() {
    return db
      .execute("SELECT * FROM products")
      .then((result) => {
        return result[0];
      })
      .catch((err) => console.log(err));
  }

  static findById(id) {
    return db.execute("SELECT * FROM products WHERE id = ?", [id]);
  }
};
